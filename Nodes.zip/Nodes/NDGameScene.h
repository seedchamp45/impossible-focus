//
//  NDGameScene.h
//  Nodes
//
//  Created by Planet 1107 on 20/01/15.
//  Copyright (c) 2015 Planet 1107. All rights reserved.
//

#import "PNTScene.h"

@protocol NDGameSceneDelegate <NSObject>

- (void)gameEnded;
- (void)twitter;
- (void)gameOver;

@end

@interface NDGameScene : PNTScene

@property (nonatomic) BOOL mute;
@property (nonatomic) id <SKSceneDelegate, NDGameSceneDelegate> delegate;

@end
