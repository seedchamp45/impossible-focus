//
//  SUDGameViewController.m
//  Nodes
//
//  Created by Planet 1107 on 19/01/15.
//  Copyright (c) 2015 Planet 1107. All rights reserved.
//
@import AdSupport;
@import CoreGraphics;
@import CoreLocation;
@import CoreTelephony;
@import EventKit;
@import EventKitUI;
@import MediaPlayer;
@import MessageUI;
@import MobileCoreServices;
@import QuartzCore;
@import Security;
@import StoreKit;
@import SystemConfiguration;
@import iAd;
#import <HeyzapAds/HeyzapAds.h>
#import "NDGameViewController.h"
#import "NDGameScene.h"
#import "NDGlobalDefines.h"
#import <Social/Social.h>
//#import <GoogleMobileAds/GoogleMobileAds.h>
#import <CoreMotion/CoreMotion.h> 
#import "GameAnalytics.h"

@interface NDGameViewController () <NDGameSceneDelegate, SKSceneDelegate>

@property (strong, nonatomic) IBOutlet UIImageView *as;


@property (strong, nonatomic) IBOutlet SKView *skView;
//@property(nonatomic, strong) GADInterstitial *interstitial;
@end

@implementation NDGameViewController
int i;
NSTimer *timer;

- (void)viewDidLoad {

    
    [super viewDidLoad];
    self.as.hidden = YES;
    NSInteger currentLevel = [[NSUserDefaults standardUserDefaults] integerForKey:kNDUserDefaultsLevelCurrent];
    
    if (currentLevel == 0) {
        timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(aTime) userInfo:nil repeats:YES];
        self.as.hidden = NO;

    }
    

     /*
    self.interstitial = [[GADInterstitial alloc] initWithAdUnitID:@"ca-app-pub-9760712752428489/8334516256"];
    
    GADRequest *request = [GADRequest request];
    // Requests test ads on test devices.
    request.testDevices = @[@"2077ef9a63d2b398840261c8221a0c9b"];
    [self.interstitial loadRequest:request];

*/
    
    // Configure the view.
    //self.skView.showsFPS = YES;
    //self.skView.showsNodeCount = YES;
    self.skView.ignoresSiblingOrder = YES;

   self.view.backgroundColor = kNDColorWhiteBackground;
   
}

-(void)aTime
{
    i++;
    NSLog(@"go: %ld",(long)i);
    if ( i==5 ) {
        self.as.hidden = YES;
        NSLog(@"yoyo");
                i = 0;
        [timer invalidate];

    }
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
}

- (void)viewWillLayoutSubviews {

    // Create and configure the scene.
    if (!self.skView.scene) {
        NDGameScene *scene = [NDGameScene sceneWithSize:self.view.bounds.size];
        scene.scaleMode = SKSceneScaleModeAspectFit;
        scene.delegate = self;
        [self.skView presentScene:scene];

    }
}


#pragma mark - NDGameSceneDelegate methods
- (void)gameOver {
    //[[[[UIApplication sharedApplication] delegate] window] rootViewController];

    NSLog(@"eieiwww");
    /*
    if ([HZInterstitialAd isAvailable]) {
        [HZInterstitialAd show];
    }
    
    if ([self.interstitial isReady]) {
        [self.interstitial presentFromRootViewController:self];
    }
    */ 
   // [HZVideoAd fetch];
   // [HZVideoAd show];
    // Rest of game over logic goes here.
   
   //  [HZInterstitialAd show];
}

- (void)twitter
{
    [GameAnalytics addDesignEventWithEventId:@"twitter button press"];
    //[eventParams setString:@"mission"    forKey:@"mission"];
     NSInteger currentLevel = [[NSUserDefaults standardUserDefaults] integerForKey:kNDUserDefaultsLevelCurrent];
    [[NSUserDefaults standardUserDefaults] synchronize];
    SLComposeViewController *composeViewController = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];

    [composeViewController setInitialText:[NSString stringWithFormat:@" “Great! I made it to [Level %ld] can you do better? #impossiblefocus #focusgame",(long)currentLevel+1]];
    [composeViewController addURL:[NSURL URLWithString:kNDAppLink]];
    [self presentViewController:composeViewController animated:YES completion:^{ }];
}


- (void)gameEnded {
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.presentingViewController dismissViewControllerAnimated:YES completion:^{}];
}

@end
