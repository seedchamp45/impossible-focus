//
//  AppDelegate.h
//  Nodes
//
//  Created by Planet 1107 on 19/01/15.
//  Copyright (c) 2015 Planet 1107. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Chartboost/Chartboost.h>
//#import "ALInterstitialAd.h"
@interface NDAppDelegate : UIResponder <UIApplicationDelegate, ChartboostDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

