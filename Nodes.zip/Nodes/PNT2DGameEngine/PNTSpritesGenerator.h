//
//  PNTGameObjectsGenerator.h
//  CarChase
//
//  Created by Planet 1107 on 22/10/14.
//  Copyright (c) 2014 Planet 1107. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PNTSprite.h"
#import "PNTScene.h"

@interface PNTSpritesGenerator : NSObject

+ (void)generateSpritesOfClass:(Class)spriteClass
                    spriteType:(NSUInteger)spriteType
                  spritesCount:(NSUInteger)spritesCount
                      forScene:(PNTScene *)scene
                onLoadedSprite:(void (^)(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount))loadedSprite
                  onCompletion:(void (^)(NSMutableArray *sprites))completion;

@end
