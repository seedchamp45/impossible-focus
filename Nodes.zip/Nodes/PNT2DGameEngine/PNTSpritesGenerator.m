//
//  PNTGameObjectsGenerator.m
//  CarChase
//
//  Created by Planet 1107 on 22/10/14.
//  Copyright (c) 2014 Planet 1107. All rights reserved.
//

#import "PNTSpritesGenerator.h"

@interface PNTSpritesGenerator ()

@property (strong, nonatomic) NSMutableDictionary *imageNameToTextureMap;

@end

@implementation PNTSpritesGenerator

- (instancetype)init {
    
    self = [super init];
    if (self) {
        _imageNameToTextureMap = [NSMutableDictionary dictionary];
    }
    return self;
}

+ (void)generateSpritesOfClass:(Class)spriteClass
                    spriteType:(NSUInteger)spriteType
                  spritesCount:(NSUInteger)spritesCount
                      forScene:(PNTScene *)scene
                onLoadedSprite:(void (^)(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount))loadedSprite
                  onCompletion:(void (^)(NSMutableArray *sprites))completion {
    
    NSMutableArray *sprites = [NSMutableArray arrayWithCapacity:spritesCount];
    
    for (uint i = 0; i < spritesCount; i++) {
        
        PNTSprite *sprite = [(PNTSprite *)[spriteClass alloc] initWithType:spriteType];
        [sprites addObject:sprite];
        
        loadedSprite(sprite, i, spritesCount);
    }
    completion(sprites);
}

@end
