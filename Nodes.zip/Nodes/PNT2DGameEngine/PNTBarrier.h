//
//  RWBarrier.h
//  Rabbit Wars
//
//  Created by Planet 1107 on 25/08/14.
//  Copyright (c) 2014 Planet 1107. All rights reserved.
//

#import "PNTSprite.h"

@interface PNTBarrier : PNTSprite

+ (instancetype)barrierWithSize:(CGSize)size;

@end
