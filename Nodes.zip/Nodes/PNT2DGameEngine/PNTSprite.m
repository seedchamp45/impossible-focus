//
//  PNTGameObject.m
//  CarChase
//
//  Created by Planet 1107 on 22/10/14.
//  Copyright (c) 2014 Planet 1107. All rights reserved.
//

#import "PNTSprite.h"

@implementation PNTSprite

- (instancetype)initWithType:(NSUInteger)spriteType {
    
    self = [super init];
    if (self) {
        [NSException raise:NSInternalInconsistencyException
                    format:@"You should override %@ in a subclass of %@, this is an abstract class! My mind to your mind... ;|", NSStringFromSelector(_cmd), NSStringFromClass(self.class)];
    }
    return self;
}

- (void)performEmitterAction:(SKEmitterNode *)emitter
                withDuration:(double)duration
                onCompletion:(void (^)())completion {
    
    if (emitter.scene) {
        [emitter removeFromParent];
    }
    emitter.zPosition = 1.0f;
    [self addChild:emitter];
    [emitter resetSimulation];
    SKAction *delay = [SKAction moveByX:0.0f y:0.0f duration:duration];
    [self runAction:delay completion:^{
        completion();
    }];
}

@end
