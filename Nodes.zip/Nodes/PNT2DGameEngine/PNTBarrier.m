//
//  RWBarrier.m
//  Rabbit Wars
//
//  Created by Planet 1107 on 25/08/14.
//  Copyright (c) 2014 Planet 1107. All rights reserved.
//

#import "PNTBarrier.h"

@implementation PNTBarrier


+ (instancetype)barrierWithSize:(CGSize)size {
    
    PNTBarrier *barrier = [[PNTBarrier alloc] initWithSize:size];
    return barrier;
}

- (instancetype)initWithSize:(CGSize)size {
    
    self = [super initWithColor:[UIColor clearColor] size:size];
    if (self) {
        [self loadPhysics];
    }
    return self;
}

- (void)loadPhysics {
    
    SKPhysicsBody *physics = [SKPhysicsBody bodyWithRectangleOfSize:self.size];
    
    physics.dynamic = NO;
    physics.categoryBitMask = 0x0000000F;
    physics.contactTestBitMask = 0xFFFFFFFF;
    
    self.physicsBody = physics;
}

@end
