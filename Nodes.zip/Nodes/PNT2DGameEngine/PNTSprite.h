//
//  PNTGameObject.h
//  CarChase
//
//  Created by Planet 1107 on 22/10/14.
//  Copyright (c) 2014 Planet 1107. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@protocol PNTSpriteGenerationProtocol <NSObject>

@required
- (instancetype)initWithType:(NSUInteger)spriteType;

@end

@interface PNTSprite : SKSpriteNode <PNTSpriteGenerationProtocol>

- (void)performEmitterAction:(SKEmitterNode *)emitter
                withDuration:(double)duration
                  onCompletion:(void (^)())completion;

@end
