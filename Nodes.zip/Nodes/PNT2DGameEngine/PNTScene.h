//
//  PNTScene.h
//  CarChase
//
//  Created by Planet 1107 on 22/10/14.
//  Copyright (c) 2014 Planet 1107. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface PNTScene : SKScene

@end
