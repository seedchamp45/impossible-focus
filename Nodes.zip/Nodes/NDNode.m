//
//  NDSprite.m
//  Nodes
//
//  Created by Planet 1107 on 20/01/15.
//  Copyright (c) 2015 Planet 1107. All rights reserved.
//

#import "NDNode.h"
#import "NDGlobalDefines.h"

@interface NDNode () <PNTSpriteGenerationProtocol>

@end

@implementation NDNode

- (instancetype)initWithType:(NSUInteger)spriteType {
    
    if (spriteType == NDNodeCenter) {
        self = [super initWithImageNamed:@"CenterNode"];
        self.labelNumber = [SKLabelNode labelNodeWithFontNamed:@"Helvetica"];
        self.labelNumber.fontSize = 30.0f;
       // self.labelNumber.hidden = YES;
    } else {
        self = [super initWithImageNamed:@"Node"];
        self.labelNumber = [SKLabelNode labelNodeWithFontNamed:@"Helvetica"];
        self.labelNumber.fontSize = 15.0f;
        //self.labelNumber.hidden = YES;
    }
    
    self.labelNumber.name = @"labelNumber";
    self.labelNumber.fontColor = kNDColorWhite;
    self.labelNumber.horizontalAlignmentMode = SKLabelHorizontalAlignmentModeCenter;
    self.labelNumber.verticalAlignmentMode = SKLabelVerticalAlignmentModeCenter;
    self.labelNumber.zPosition = 10.0f;
    [self convertPoint:_labelNumber.position toNode:self];
    [self addChild:self.labelNumber];
    

    
    self.name = @"node";
    
    _nodeType = spriteType;
  
            [self setNodeColor:NDNodeBlack];



    
    return self;
}

- (void)loadPhysics {
    
    SKPhysicsBody *physics;
    if (self.nodeType == NDNodeCenter) {
        physics = [SKPhysicsBody bodyWithCircleOfRadius:self.size.width/2 -2.0f];
        physics.dynamic = NO;
    } else if (self.nodeType == NDNodeFree) {
        physics = [SKPhysicsBody bodyWithCircleOfRadius:self.size.width/2];
        physics.dynamic = NO;
    }
    else {
        physics = [SKPhysicsBody bodyWithCircleOfRadius:self.size.width/2 ];
        physics.dynamic = YES;
    }
    
    physics.affectedByGravity = NO;
    physics.categoryBitMask = kNDNodeCategoryMask;
    physics.contactTestBitMask = kNDNodeCategoryMask;
    physics.collisionBitMask = kNDNodeCategoryMask;
//    physics.usesPreciseCollisionDetection = YES;

    physics.mass = 10.0f;
    
    self.physicsBody = physics;
}

- (void)startRotating {
    
    if (self.nodeType == NDNodeCenter && ![self actionForKey:@"rotation"]) {
        SKAction *rotate = [SKAction repeatActionForever:[SKAction rotateByAngle:-M_2_PI duration: 0.4]];
        [self runAction:rotate withKey:@"rotation"];
    }
}
- (void)startRotating2 {
    
    if (self.nodeType == NDNodeCenter && ![self actionForKey:@"rotation"]) {
        SKAction *rotate = [SKAction repeatActionForever:[SKAction rotateByAngle:M_2_PI duration: 0.4]];
        [self runAction:rotate withKey:@"rotation"];
    }
}

- (void)startRotating3 {
    
    if (self.nodeType == NDNodeCenter && ![self actionForKey:@"rotation"]) {
        SKAction *rotate = [SKAction repeatActionForever:[SKAction rotateByAngle:M_2_PI duration: 0.6]];
        [self runAction:rotate withKey:@"rotation"];
    }
}

- (void)startRotating4 {
    
    if (self.nodeType == NDNodeCenter && ![self actionForKey:@"rotation"]) {
        SKAction *rotate = [SKAction repeatActionForever:[SKAction rotateByAngle:M_2_PI duration: 0.3]];
        [self runAction:rotate withKey:@"rotation"];
    }
}

- (void)startRotating5 {
    
    if (self.nodeType == NDNodeCenter && ![self actionForKey:@"rotation"]) {
        SKAction *rotate = [SKAction repeatActionForever:[SKAction rotateByAngle:-M_2_PI duration: 0.3]];
        [self runAction:rotate withKey:@"rotation"];
    }
}
- (void)stopRotating {
    
    [self removeActionForKey:@"rotation"];
}

- (BOOL)isRotating {
    
    if ([self actionForKey:@"rotation"]) {
        return YES;
    } else {
        return NO;
    }
}

- (SKPhysicsJointFixed *)createLinkToCenterNode:(NDNode *)centerNode {
    
    SKPhysicsJointFixed *jointToCenter;
    if (centerNode.nodeType == NDNodeCenter) {
        self.nodeLink = [[SKSpriteNode alloc] initWithColor:[self colorForNDColor:self.nodeColor] size:CGSizeMake(centerNode.size.width/2 , 1.0f)];
        self.nodeLink.name = @"link";
        self.nodeLink.zPosition = -1.0f;
        self.nodeLink.anchorPoint = CGPointMake(0.0f, 1.0f);
        CGFloat angle = atan2f(centerNode.position.y - self.position.y, centerNode.position.x - self.position.x);
        self.nodeLink.zRotation = angle;
        [self addChild:self.nodeLink];
        
        jointToCenter = [SKPhysicsJointFixed jointWithBodyA:centerNode.physicsBody bodyB:self.physicsBody anchor:centerNode.position];
    }
    return jointToCenter;
}

- (void)setNodeColor:(NDNodeColor)nodeColor {
    
    _nodeColor = nodeColor;
    if (self.nodeType == NDNodeCenter) {
        if (nodeColor == NDNodeYellow) {
            self.texture = [SKTexture textureWithImageNamed:@"CenterNode-yellow"];
        } else if (nodeColor == NDNodePink) {
            self.texture = [SKTexture textureWithImageNamed:@"CenterNode-pink"];
        } else if (nodeColor == NDNodeBlue) {
            self.texture = [SKTexture textureWithImageNamed:@"CenterNode-blue"];
        } else {
            self.texture = [SKTexture textureWithImageNamed:@"CenterNode"];
        }
    } else {
        if (nodeColor == NDNodeYellow) {
            self.texture = [SKTexture textureWithImageNamed:@"Node-yellow"];
        } else if (nodeColor == NDNodePink) {
            self.texture = [SKTexture textureWithImageNamed:@"Node-pink"];
        } else if (nodeColor == NDNodeBlue) {
            self.texture = [SKTexture textureWithImageNamed:@"Node-blue"];
        } else {
            self.texture = [SKTexture textureWithImageNamed:@"Node"];
        }
    }
    if (self.nodeLink) {
        self.nodeLink.color = [self colorForNDColor:nodeColor];
    }
}

- (UIColor *)colorForNDColor:(NDNodeColor)nodeColor {
    
    if (nodeColor == NDNodeYellow) {
        return kNDColorYellow;
    } else if (nodeColor == NDNodePink) {
        return kNDColorPink;
    } else if (nodeColor == NDNodeBlue) {
        return kNDColorBlue;
    } else {
        return kNDColorBlack;
    }
}

@end
