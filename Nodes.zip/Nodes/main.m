//
//  main.m
//  Nodes
//
//  Created by Planet 1107 on 19/01/15.
//  Copyright (c) 2015 Planet 1107. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NDAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NDAppDelegate class]));
    }
}
