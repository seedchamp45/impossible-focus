//
//  NDGameScene.m
//  Nodes
//
//  Created by Planet 1107 on 20/01/15.
//  Copyright (c) 2015 Planet 1107. All rights reserved.
//
//#import "ALSdk.h"
@import AdSupport;
@import CoreGraphics;
@import CoreLocation;
@import CoreTelephony;
@import EventKit;
@import EventKitUI;
@import MediaPlayer;
@import MessageUI;
@import MobileCoreServices;
@import QuartzCore;
@import Security;
@import StoreKit;
@import SystemConfiguration;
@import iAd;
//#import <HeyzapAds/HeyzapAds.h>
#import "NDGameScene.h"
#import "PNTSpritesGenerator.h"
#import "NDGameViewController.h"
#import "NDNode.h"
#import "NDGlobalDefines.h"
#import <Twitter/Twitter.h>
#import <CommonCrypto/CommonDigest.h>
#import <AdSupport/AdSupport.h>
#import <QuartzCore/QuartzCore.h>
#import <Chartboost/Chartboost.h>
#import "GameAnalytics.h"


@interface NDGameScene () <SKPhysicsContactDelegate,UIAlertViewDelegate>

@property (strong, nonatomic) NDNode *nodeCenter;
@property (strong, nonatomic) UILabel *text;
@property (strong, nonatomic) NSMutableArray *nodesLocked;
@property (strong, nonatomic) NSMutableArray *nodesFree;
@property (nonatomic) NSUInteger level;

@end

@implementation NDGameScene
int i = 0;
int j;
int x;
NSTimer *timer;

- (id)initWithSize:(CGSize)size {
    
    self = [super initWithSize:size];
    if (self) {
        
        [SKAction playSoundFileNamed:@"userLost.wav" waitForCompletion:NO];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillResignActive:) name:UIApplicationWillResignActiveNotification object:nil];
        _nodesLocked = [[NSMutableArray alloc] init];
        _nodesFree = [[NSMutableArray alloc] init];
        
        _mute = [[NSUserDefaults standardUserDefaults] boolForKey:kNDUserDefaultsMuteSound];
        _level = [[NSUserDefaults standardUserDefaults] integerForKey:kNDUserDefaultsLevelCurrent];
    }
    return self;
}

- (void)didMoveToView:(SKView *)view {
    /* Setup your scene here */
    
    if (!self.nodeCenter) {
        [self initialSceneSetup];
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    self.paused = YES;
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    self.paused = NO;
}


#pragma mark - Helper methods

- (void)initialSceneSetup {
    j = 0;
    
    int i = arc4random() %4;
    if (i == 0) {
        self.backgroundColor = kNDColorWhiteBackground;
    }
    if (i == 1) {
         self.backgroundColor = kNDColorYellow;
    }
    if (i == 2) {
        self.backgroundColor = kNDColorPink;
    }
    if (i == 3) {
        self.backgroundColor = kNDColorBlue;
    }
    
    NDNodeType nodeType = NDNodeCenter;
    [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:1 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
        
    } onCompletion:^(NSMutableArray *sprites) {
        self.nodeCenter = (NDNode *)sprites.firstObject;
        self.nodeCenter.position = CGPointMake(CGRectGetMidX(self.frame), CGRectGetMaxY(self.frame)  - self.nodeCenter.size.height/2 - 40.0f);
        [self.nodeCenter loadPhysics];
        [self addChild:self.nodeCenter];
        
        SKFieldNode *field = [SKFieldNode radialGravityField];
        field.strength = 100.0f;
        [self.nodeCenter addChild:field];
    }];
    
    [self setUpNextLevel];
    
    self.physicsWorld.contactDelegate = self;
}



- (void)setUpNextLevel {
    x = 12;
    
    [[NSUserDefaults standardUserDefaults] setInteger:self.level forKey:kNDUserDefaultsLevelCurrent];
    //NSLog(@"%@ label", [self childNodeWithName:@"labelNumber"].name);
    //self.text = SKLabelVerticalAlignmentModeCenter;
    
    [self.nodeCenter stopRotating];
    
    [self.physicsWorld removeAllJoints];
    
    [self.nodesLocked makeObjectsPerformSelector:@selector(removeFromParent)];
    [self.nodesLocked removeAllObjects];
    
    [self.nodesFree makeObjectsPerformSelector:@selector(removeFromParent)];
    [self.nodesFree removeAllObjects];
    
    self.paused = NO;
    

        
    
    
    NDNodeType nodeType = NDNodeLocked;
    if (self.level == 0) {
        
        
            self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 1];
    [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:1 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
        
    } onCompletion:^(NSMutableArray *sprites) {
        for (int i = 0; i < sprites.count; i++) {
            NDNode *node = sprites[i];
            node.position = [self pointForLockedNode:node];
            [node loadPhysics];
            [self addChild:node];
            [self.nodesLocked addObject:node];
        }
        [self.nodeCenter startRotating3];
    }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 6;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 6 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 1) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 2];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:5 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
        
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating2];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 6;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 6 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    if (self.level == 2) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 3];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:7 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 6;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 6 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 3) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 4];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:8 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating4];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 7;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 7 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 4) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 5];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:9 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 9;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 9- i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 5) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 6];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:9 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating5];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 9;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 9 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 6) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 7];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:8 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 12;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 12 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 7) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 8];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:8 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating4];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 12;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d",12 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    if (self.level == 8) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 9];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:7 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating5];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 12;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 12 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 9) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 10];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:8 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 12;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 12 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 10) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 11];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:8 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating3];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 14;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 14 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    if (self.level == 11) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 12];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:8 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 13;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 13 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    if (self.level == 12) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 13];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:7 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating2];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 11;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d",11 - i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 13) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 14];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:5 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 11;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 11- i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }

    if (self.level == 14) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 15];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:6 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 12;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 12- i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 15) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 16];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:7 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 12;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 12- i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 16) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 17];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:7 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 13;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 13- i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 17) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 18];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:8 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 13;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 13- i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }

    if (self.level == 18) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 19];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:8 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 13;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 13- i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }
    
    if (self.level == 19) {
        self.nodeCenter.labelNumber.text = [NSString stringWithFormat:@"%d", 20];
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:7 forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.position = [self pointForLockedNode:node];
                [node loadPhysics];
                [self addChild:node];
                [self.nodesLocked addObject:node];
            }
            [self.nodeCenter startRotating];
        }];
        nodeType = NDNodeFree;
        NSInteger freeNodesCount = 12;
        
        [PNTSpritesGenerator generateSpritesOfClass:NDNode.class spriteType:nodeType spritesCount:freeNodesCount forScene:self onLoadedSprite:^(PNTSprite *sprite, NSUInteger loadedSpritesCount, NSUInteger totalSpritesCount) {
            
        } onCompletion:^(NSMutableArray *sprites) {
            
            for (int i = 0; i < sprites.count; i++) {
                NDNode *node = sprites[i];
                node.labelNumber.text = [NSString stringWithFormat:@"%d", 12- i];
                node.position = CGPointMake(CGRectGetWidth(self.scene.frame) / 2, (CGRectGetMinY(self.nodeCenter.frame) - 120.0f - (i * CGRectGetHeight(node.frame) * 1.5)));
                [node loadPhysics];
                [self addChild:node];
                [self.nodesFree addObject:node];
            }
        }];
        
    }


}

- (CGPoint)pointForLockedNode:(NDNode *)lockedNode {
    
    float angleInRadians = arc4random_uniform(100)/100.0f * 2 * M_PI;
    float xDiff = cosf(angleInRadians) * (self.nodeCenter.size.width/2 + lockedNode.size.width/2);
    float yDiff = sinf(angleInRadians) * (self.nodeCenter.size.height/2 + lockedNode.size.height/2);
    
    CGPoint nodeLocation = CGPointMake(self.nodeCenter.position.x + xDiff, self.nodeCenter.position.y + yDiff);
    
    BOOL locationPossible = YES;
    for (int i = 0; i < self.nodesLocked.count; i++) {
        NDNode *node = self.nodesLocked[i];
        CGFloat xDist = (node.position.x - nodeLocation.x);
        CGFloat yDist = (node.position.y - nodeLocation.y);
        CGFloat distance = sqrt((xDist * xDist) + (yDist * yDist));
        if (distance < lockedNode.size.width * 2.1) {
            locationPossible = NO;
            break;
        }
    }
    if (locationPossible) {
        return nodeLocation;
    } else {
        return [self pointForLockedNode:lockedNode];
    }
}

- (void)userWon {
    
    [self.nodeCenter runAction:[SKAction setTexture:[SKTexture textureWithImageNamed:@"centernode-win"] resize:YES]];
    [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    self.backgroundColor = kNDColorGreenBackground;
    [self.nodeCenter stopRotating];
    
    SKAction *scale = [SKAction scaleTo:2.0f duration:0.2];
    SKAction *scale2 = [SKAction scaleTo:0.0f duration:0.2];
    SKAction *normalScale = [SKAction scaleTo:1.0 duration:0.2];
    [self.nodeCenter runAction:scale completion:^{
        [self.nodeCenter runAction:normalScale];
    }];
    
    for (NDNode *lockedNode in self.nodesLocked) {
        lockedNode.physicsBody.dynamic = NO;
        [lockedNode runAction:scale2 completion:^{
            [lockedNode runAction:normalScale];
        }];
    }
    for (NDNode *freeNode in self.nodesFree) {
        freeNode.physicsBody.dynamic = NO;
        [freeNode runAction:scale completion:^{
            [freeNode runAction:normalScale];
        }];
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.backgroundColor = kNDColorWhiteBackground;
        ++self.level;
        if (self.level < kNDMaxNodesLocked - kNDMinNodesLocked) {
            NSInteger lastLevelReached = [[NSUserDefaults standardUserDefaults] integerForKey:kNDUserDefaultsLevelReached];
            if (self.level > lastLevelReached) {
                [[NSUserDefaults standardUserDefaults] setInteger:self.level forKey:kNDUserDefaultsLevelReached];
            }
            [self setUpNextLevel];
        } else {
            if ([self.delegate respondsToSelector:@selector(gameEnded)]) {
                [self.delegate gameEnded];
            }
        }
    });
    if (!self.mute) {
        
        [self runAction:[SKAction playSoundFileNamed:@"userWon.wav" waitForCompletion:NO]];
    }
}

- (void)userLost {
    [self.nodeCenter runAction:[SKAction setTexture:[SKTexture textureWithImageNamed:@"centernode-lose"] resize:YES]];
    self.userInteractionEnabled = NO;
    if ([self.nodeCenter isRotating]) {
        [self.nodeCenter stopRotating];
        
        self.backgroundColor = kNDColorRedBackground;
        
        SKAction *rightShake = [SKAction moveByX:5.0 y:0.0 duration:0.03];
        SKAction *leftShake = [SKAction moveByX:-5.0 y:0.0 duration:0.03];
        SKAction *shake = [SKAction sequence:@[rightShake, leftShake, rightShake, leftShake, rightShake, leftShake]];
        [self.nodeCenter runAction:shake completion:^{
            SKAction *scale = [SKAction scaleTo:2.0f duration:0.2];
            SKAction *normalScale = [SKAction scaleTo:1.0 duration:0.2];
            [self.nodeCenter runAction:scale completion:^{
                [self.nodeCenter runAction:normalScale];
            }];
            for (NDNode *lockedNode in self.nodesLocked) {
                lockedNode.physicsBody.dynamic = NO;
                [lockedNode runAction:scale completion:^{
                    [lockedNode runAction:normalScale];
                }];
            }
            for (NDNode *freeNode in self.nodesFree) {
                freeNode.physicsBody.dynamic = NO;
                [freeNode runAction:scale completion:^{
                    [freeNode runAction:normalScale];
                }];
            }
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.backgroundColor = kNDColorWhiteBackground;
                if ([self.delegate respondsToSelector:@selector(gameEnded)]) {
                [self.delegate gameEnded];
                }
            });
        }];
        for (NDNode *lockedNode in self.nodesLocked) {
            lockedNode.physicsBody.dynamic = NO;
            [lockedNode runAction:shake];
        }
        for (NDNode *freeNode in self.nodesFree) {
            freeNode.physicsBody.dynamic = NO;
            [freeNode runAction:shake];
        }
    }
    if (!self.mute) {
        [self runAction:[SKAction playSoundFileNamed:@"userLost.wav" waitForCompletion:NO]];
    }
}


#pragma mark - UIResponder methods

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    /* Called when a touch begins */
    
    NSLog(@"intintj: %d",x);

    
    if (self.nodesFree.count) {
   
        self.userInteractionEnabled = NO;

        NDNode *node = self.nodesFree.firstObject;
        node.physicsBody.dynamic = YES;
        
        for (int i = 0; i < self.nodesFree.count; i++) {
            NDNode *node = self.nodesFree[i];
        
            SKAction *moveUp = [SKAction moveByX:0.0f y:CGRectGetHeight(node.frame) * 1.5 duration:0.1];
            [node runAction:moveUp];
           // NSLog(@"show: %lu",(unsigned long)self.nodesFree.count);
            //NSLog(@"show2: %d",i);

     
           
        }
    }

}

- (void)update:(CFTimeInterval)currentTime {
    /* Called before each frame is rendered */
    
}


#pragma mark - SKPhysicsContactDelegate methods

- (void)didBeginContact:(SKPhysicsContact *)contact {
   // BOOL begincontact = YES;
   

    //NSLog(@"int2: %d",j);
    NDNode *firstNode = (NDNode *)contact.bodyA.node;
    NDNode *secondNode = (NDNode *)contact.bodyB.node;
    
    if (firstNode.nodeType == NDNodeCenter || secondNode.nodeType == NDNodeCenter) {
        //success, node collided with center node
        
        if ((firstNode.nodeType == NDNodeCenter && secondNode.nodeType == NDNodeLocked) || (firstNode.nodeType == NDNodeLocked && secondNode.nodeType == NDNodeCenter)) {
            //if the level just started initial collisions will happen between center and "fixed" nodes

            
            if (firstNode.nodeType == NDNodeLocked) {
                //recalculate node position of "free" node to avoid low FPS problems
                CGFloat angleInRadians = atan2f(firstNode.position.y - secondNode.position.y, firstNode.position.x - secondNode.position.x);
                float xDiff = cosf(angleInRadians) * (self.nodeCenter.size.height/2 + firstNode.size.height/2);
                float yDiff = sinf(angleInRadians) * (self.nodeCenter.size.width/2 + firstNode.size.width/2);
                
                CGPoint nodeLocation = CGPointMake(self.nodeCenter.position.x + xDiff, self.nodeCenter.position.y + yDiff);
                firstNode.position = nodeLocation;
                
                SKPhysicsJointFixed *jointToCenter = [firstNode createLinkToCenterNode:self.nodeCenter];
                [self.physicsWorld addJoint:jointToCenter];
            }

            else {
                //recalculate node position of "free" node to avoid low FPS problems
                CGFloat angleInRadians = atan2f(secondNode.position.y - firstNode.position.y, secondNode.position.x - firstNode.position.x);
                float xDiff = cosf(angleInRadians) * (self.nodeCenter.size.height/2 + secondNode.size.height/2);
                float yDiff = sinf(angleInRadians) * (self.nodeCenter.size.width/2 + secondNode.size.width/2);
                
                CGPoint nodeLocation = CGPointMake(self.nodeCenter.position.x + xDiff, self.nodeCenter.position.y + yDiff);
                secondNode.position = nodeLocation;
                
                SKPhysicsJointFixed *jointToCenter = [secondNode createLinkToCenterNode:self.nodeCenter];
                [self.physicsWorld addJoint:jointToCenter];
         
            }
            
        } else if (firstNode.nodeType == NDNodeFree || secondNode.nodeType == NDNodeFree) {
            //"free" node collided with center node
            [self.nodeCenter runAction:[SKAction setTexture:[SKTexture textureWithImageNamed:@"centernode-win"] resize:YES]];

            x--;
            UIBlurEffect *blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            UIVisualEffectView *blurEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
            UIBlurEffect *blurEffect2 = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            UIVisualEffectView *blurEffectView2 = [[UIVisualEffectView alloc] initWithEffect:blurEffect2];
            UIBlurEffect *blurEffect3 = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            UIVisualEffectView *blurEffectView3 = [[UIVisualEffectView alloc] initWithEffect:blurEffect3];
            UIBlurEffect *blurEffect4 = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            UIVisualEffectView *blurEffectView4 = [[UIVisualEffectView alloc] initWithEffect:blurEffect4];
            UIBlurEffect *blurEffect5 = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            UIVisualEffectView *blurEffectView5 = [[UIVisualEffectView alloc] initWithEffect:blurEffect5];
            UIBlurEffect *blurEffect6 = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            UIVisualEffectView *blurEffectView6 = [[UIVisualEffectView alloc] initWithEffect:blurEffect6];
            UIBlurEffect *blurEffect7 = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            UIVisualEffectView *blurEffectView7 = [[UIVisualEffectView alloc] initWithEffect:blurEffect7];
            UIBlurEffect *blurEffect8 = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            UIVisualEffectView *blurEffectView8 = [[UIVisualEffectView alloc] initWithEffect:blurEffect8];
            UIBlurEffect *blurEffect9 = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            UIVisualEffectView *blurEffectView9 = [[UIVisualEffectView alloc] initWithEffect:blurEffect9];
            UIBlurEffect *blurEffect10 = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            UIVisualEffectView *blurEffectView10 = [[UIVisualEffectView alloc] initWithEffect:blurEffect10];
            UIBlurEffect *blurEffect11 = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            UIVisualEffectView *blurEffectView11 = [[UIVisualEffectView alloc] initWithEffect:blurEffect11];

            if (x == 11) {
                timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(aTime) userInfo:nil repeats:YES];
                blurEffectView.alpha = 0.05;
                blurEffectView.frame = self.view.bounds;
                blurEffectView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                
                [self.view addSubview:blurEffectView];
            }
            
            if (x == 10) {
         
                [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [blurEffectView removeFromSuperview];
                blurEffectView2.alpha = 0.075;
                blurEffectView2.frame = self.view.bounds;
                blurEffectView2.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                
                [self.view addSubview:blurEffectView2];
            }
            
            if (x == 9) {
                timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(aTime) userInfo:nil repeats:YES];
      
                [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [blurEffectView removeFromSuperview];
                blurEffectView3.alpha = 0.15;
                blurEffectView3.frame = self.view.bounds;
                blurEffectView3.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                
                [self.view addSubview:blurEffectView3];
            }
            
            if (x == 8) {
      
                [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [blurEffectView removeFromSuperview];
                blurEffectView4.alpha = 0.225;
                blurEffectView4.frame = self.view.bounds;
                blurEffectView4.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                
                [self.view addSubview:blurEffectView4];
            }
            
            if (x == 7) {
                            timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(aTime) userInfo:nil repeats:YES];
                [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [blurEffectView removeFromSuperview];
                blurEffectView5.alpha = 0.3;
                blurEffectView5.frame = self.view.bounds;
                blurEffectView5.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                
                [self.view addSubview:blurEffectView5];
            }
            
            if (x == 6) {
 
                [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [blurEffectView removeFromSuperview];
                blurEffectView6.alpha = 0.375;
                blurEffectView6.frame = self.view.bounds;
                blurEffectView6.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                
                [self.view addSubview:blurEffectView6];
            }
            
            if (x == 5) {
            timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(aTime) userInfo:nil repeats:YES];
                [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [blurEffectView removeFromSuperview];
                blurEffectView7.alpha = 0.45;
                blurEffectView7.frame = self.view.bounds;
                blurEffectView7.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                
                [self.view addSubview:blurEffectView7];
            }
            
            if (x == 4) {

                [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [blurEffectView removeFromSuperview];
                blurEffectView8.alpha = 0.525;
                blurEffectView8.frame = self.view.bounds;
                blurEffectView8.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                
                [self.view addSubview:blurEffectView8];
            }
            
            if (x == 3) {
              timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(aTime) userInfo:nil repeats:YES];
                [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [blurEffectView removeFromSuperview];
                blurEffectView9.alpha = 0.7;
                blurEffectView9.frame = self.view.bounds;
                blurEffectView9.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                
                [self.view addSubview:blurEffectView9];
            }
            
            if (x == 2) {
            timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(aTime) userInfo:nil repeats:YES];
                [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [blurEffectView removeFromSuperview];
                blurEffectView10.alpha = 0.775;
                blurEffectView10.frame = self.view.bounds;
                blurEffectView10.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                
                [self.view addSubview:blurEffectView10];
            }
            
            if (x == 1) {

                [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [blurEffectView removeFromSuperview];
                blurEffectView11.alpha = 0.85;
                blurEffectView11.frame = self.view.bounds;
                blurEffectView11.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                
                [self.view addSubview:blurEffectView11];
            }
            
 

       
            
            
            if (self.nodesFree.count == 0) {
  
                [[self.view subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
                [blurEffectView removeFromSuperview];
            }


 
            
      
            
            if(firstNode.nodeType == NDNodeFree || secondNode.nodeType == NDNodeLocked)
            {
                NSLog(@"no");
                //recalculate node position of "free" node to avoid low FPS problems
                
                
            }
            else{
                 [self runAction:[SKAction playSoundFileNamed:@"BubblePo-Benjamin-8920_hifi.wav" waitForCompletion:NO]];
                NDNode *nodeFree = self.nodesFree[0];
                nodeFree.nodeType = NDNodeLocked;
                [self.nodesFree removeObjectAtIndex:0];
                [self.nodesLocked addObject:nodeFree];
                
                //recalculate node position of "free" node to avoid low FPS problems
                CGFloat angleInRadians = atan2f(nodeFree.position.y - self.nodeCenter.position.y, nodeFree.position.x - self.nodeCenter.position.x);
                float xDiff = cosf(angleInRadians) * (self.nodeCenter.size.width/2 + nodeFree.size.width/2);
                float yDiff = sinf(angleInRadians) * (self.nodeCenter.size.height/2 + nodeFree.size.height/2);
                
                CGPoint nodeLocation = CGPointMake(self.nodeCenter.position.x + xDiff, self.nodeCenter.position.y + yDiff);
                nodeFree.position = nodeLocation;
            SKPhysicsJointFixed *jointToCenter = [nodeFree createLinkToCenterNode:self.nodeCenter];
                [self.physicsWorld addJoint:jointToCenter];
            }
       
        }
      
            if (self.nodesFree.count == 0) {
                [self userWon];
            }
        
        self.userInteractionEnabled = YES;
    }
/*

    else if(firstNode.nodeType == NDNodeFree || secondNode.nodeType == NDNodeLocked)
    {
        NSLog(@"no");
        //recalculate node position of "free" node to avoid low FPS problems
        
        
    }
*/
    else {
        //failed, "free" node collided with "fixed" node
        
        if (j == 0) {
            [self userlost2];
            
            j++;
            
        }
        else {
            [self userLost];
        }
      //  NSLog(@"int: %d",j);
        //[self userLost];
    }
}

-(void)aTime
{

    i++;
    NSLog(@"gogo: %ld",(long)i);
    if ( i==2 ) {
        [self.nodeCenter runAction:[SKAction setTexture:[SKTexture textureWithImageNamed:@"CenterNode"] resize:YES]];
        NSLog(@"yoyo");
        i = 0;

        [timer invalidate];
    }
    if ( i > 2 ) {
        [self.nodeCenter runAction:[SKAction setTexture:[SKTexture textureWithImageNamed:@"CenterNode"] resize:YES]];
        NSLog(@"yoyo");
         i = 0;
        [timer invalidate];
       
    }
}
- (void)alertView:(UIAlertView *)alertView
clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == [alertView cancelButtonIndex]){
        
        
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.backgroundColor = kNDColorWhiteBackground;
            if ([self.delegate respondsToSelector:@selector(gameEnded)]) {
                [self.delegate gameEnded];
            }
        });
    }

     else if (buttonIndex ==  [alertView firstOtherButtonIndex])
    {

        // InterstitialAds are automatically fetched from our server
         [GameAnalytics addDesignEventWithEventId:@"ad button press"];
        //[HZInterstitialAd show];
        
       // [HeyzapAds startWithPublisherID: @"f9ffec7444f543f2a428e4b6f22c75be" andOptions: HZAdOptionsDisableAutoPrefetching];
      
        //[HZVideoAd fetch];
        //[HZVideoAd show];
        [Chartboost showRewardedVideo:CBLocationMainMenu];
        self.backgroundColor = kNDColorWhiteBackground;
        NSLog(@"eiei");
        if (self.level == 0) {
            [self.nodeCenter startRotating3];
        }
        if (self.level == 1) {
            [self.nodeCenter startRotating2];
        }
        if (self.level == 2) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 3) {
            [self.nodeCenter startRotating4];
        }
        if (self.level == 4) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 5) {
            [self.nodeCenter startRotating5];
        }
        if (self.level == 6) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 7) {
            [self.nodeCenter startRotating4];
        }
        if (self.level == 8) {
            [self.nodeCenter startRotating5];
        }
        if (self.level == 9) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 10) {
            [self.nodeCenter startRotating3];
        }
        if (self.level == 11) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 12) {
            [self.nodeCenter startRotating2];
        }
        if (self.level == 13) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 14) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 15) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 16) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 17) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 18) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 19) {
            [self.nodeCenter startRotating];
        }
        for (NDNode *lockedNode in self.nodesLocked)
        {
            lockedNode.physicsBody.dynamic = YES;
        }
        /*
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.backgroundColor = kNDColorWhiteBackground;
            if ([self.delegate respondsToSelector:@selector(gameOver)]) {
                [self.delegate gameOver];
            }
        });
        */
        self.userInteractionEnabled = YES;
        
        
        NDNode *node = self.nodesFree.firstObject;
        node.physicsBody.dynamic = YES;
        NDNode *nodeFree = self.nodesFree[0];
        nodeFree.nodeType = NDNodeLocked;
        [self.nodesFree removeObjectAtIndex:0];
        [self.nodesLocked addObject:nodeFree];
        
        if (self.nodesFree.count == 0) {
            [self userWon];
        }
        
    }
    else
    {
        self.backgroundColor = kNDColorWhiteBackground;
        NSLog(@"eiei");
        if (self.level == 0) {
            [self.nodeCenter startRotating3];
        }
        if (self.level == 1) {
            [self.nodeCenter startRotating2];
        }
        if (self.level == 2) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 3) {
            [self.nodeCenter startRotating4];
        }
        if (self.level == 4) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 5) {
            [self.nodeCenter startRotating5];
        }
        if (self.level == 6) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 7) {
            [self.nodeCenter startRotating4];
        }
        if (self.level == 8) {
            [self.nodeCenter startRotating5];
        }
        if (self.level == 9) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 10) {
            [self.nodeCenter startRotating3];
        }
        if (self.level == 11) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 12) {
            [self.nodeCenter startRotating2];
        }
        if (self.level == 13) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 14) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 15) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 16) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 17) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 18) {
            [self.nodeCenter startRotating];
        }
        if (self.level == 19) {
            [self.nodeCenter startRotating];
        }
        
        
        for (NDNode *lockedNode in self.nodesLocked)
        {
            lockedNode.physicsBody.dynamic = YES;
        }
        
        
        self.userInteractionEnabled = YES;
        
        
        NDNode *node = self.nodesFree.firstObject;
        node.physicsBody.dynamic = YES;
        NDNode *nodeFree = self.nodesFree[0];
        nodeFree.nodeType = NDNodeLocked;
        [self.nodesFree removeObjectAtIndex:0];
       [self.nodesLocked addObject:nodeFree];
        
        if (self.nodesFree.count == 0) {
            [self userWon];
        }


        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.backgroundColor = kNDColorWhiteBackground;
            if ([self.delegate respondsToSelector:@selector(twitter)]) {
                [self.delegate twitter];
            }
        });
    
    }

}



-(void)userlost2
{
    [self.nodeCenter runAction:[SKAction setTexture:[SKTexture textureWithImageNamed:@"centernode-lose"] resize:YES]];

    
    self.backgroundColor = kNDColorRedBackground;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Thank you for playing"
                                                    message:@"To continue tap here"
                                                   delegate:self
                                          cancelButtonTitle:@"Retry"
                                          otherButtonTitles:@"Watch Ad",@"Share on twitter", nil];
    
    [alert show];

    self.userInteractionEnabled = NO;
    SKAction *scale = [SKAction scaleTo:2.0f duration:0.2];
    SKAction *normalScale = [SKAction scaleTo:1.0 duration:0.2];
    SKAction *normalScale2 = [SKAction scaleTo:0.0 duration:0.2];
    
    if (!self.mute) {
        [self runAction:[SKAction playSoundFileNamed:@"userLost.wav" waitForCompletion:NO]];
    }

    [self.nodeCenter stopRotating];
    
    for (NDNode *lockedNode in self.nodesLocked) {
        lockedNode.physicsBody.dynamic = NO;
        [lockedNode runAction:normalScale2 completion:^{
            [lockedNode runAction:normalScale];
        }];
    }

    
    NDNode *freeNode = self.nodesFree.firstObject;
    freeNode.physicsBody.dynamic = NO;
  
        [freeNode runAction:scale completion:^{
            [freeNode runAction:normalScale2];
            [freeNode removeFromParent];
        }];
    
    
    
}

-(void)didSimulatePhysics {
    
    //minor animations customizations
    [self enumerateChildNodesWithName:@"node" usingBlock:^(SKNode *node, BOOL *stop) {
        for (SKNode *childNode in node.children) {
            if ([childNode.name isEqualToString:@"labelNumber"]) {
                childNode.zRotation = -node.zRotation;
            } else if ([childNode.name isEqualToString:@"link"]) {
                [childNode setScale:1.0f/node.yScale];
            }
        }
    }];
}

- (void)dealloc {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillResignActiveNotification object:nil];
}

@end
