//
//  NDGlobalDefines.h
//  Nodes
//
//  Created by Planet 1107 on 27/01/15.
//  Copyright (c) 2015 Planet 1107. All rights reserved.
//

#ifndef Nodes_NDGlobalDefines_h
#define Nodes_NDGlobalDefines_h

#define kNDAppLink @"https://itunes.apple.com/us/app/apple-store"

#define kNDUserDefaultsMuteSound @"muteSound"
#define kNDUserDefaultsLevelCurrent @"levelCurrent"
#define kNDUserDefaultsLevelReached @"levelReached"

#define kNDButtonImageNameSoundOff @"btn-sound-off"
#define kNDButtonImageNameSoundOn @"btn-sound-on"

#define kNDMinNodesLocked 0
#define kNDMaxNodesLocked 20
#define kNDMinNodesFree 1

#define kNDMaxNodesFree 8
//#define kNDColorWhiteBackground [UIColor colorWithPatternImage:[UIImage imageNamed:@"bd3"]]
#define kNDColorWhiteBackground [UIColor colorWithRed:152.0f/255.0f green:200.0f/255.0f blue:250.0f/255.0f alpha:0.7f]
#define kNDColorGreenBackground [UIColor colorWithRed:0.0f green:1.0f blue:49.0f/255.0f alpha:1.0f]
#define kNDColorRedBackground [UIColor colorWithRed:1.0f green:1.0f/255.0f blue:74.0f/255.0f alpha:1.0f]

#define kNDColorYellow [UIColor colorWithRed:180.0f/255.0f green:160.0f/255.0f blue:49.0f/255.0f alpha:1.0f]
#define kNDColorPink [UIColor colorWithRed:100.0f/255.0f green:141.0f/255.0f blue:137.0f/255.0f alpha:1.0f]
#define kNDColorBlue [UIColor colorWithRed:102.0f/255.0f green:182.0f/255.0f blue:1.0f alpha:1.0f]
#define kNDColorBlack [UIColor blackColor]
#define kNDColorWhite [UIColor whiteColor]

#endif
