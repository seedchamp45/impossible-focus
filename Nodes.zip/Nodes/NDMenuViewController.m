//
//  NDMenuViewController.m
//  Nodes
//
//  Created by Planet 1107 on 26/01/15.
//  Copyright (c) 2015 Planet 1107. All rights reserved.
//

#import "NDMenuViewController.h"
#import "NDGameViewController.h"
#import <Social/Social.h>
#import <iAd/iAd.h>
#import "NDGlobalDefines.h"
//#import <GoogleMobileAds/GoogleMobileAds.h>
#import "ABGameKitHelper.h"
#import "GameAnalytics.h"
#import <HeyzapAds/HeyzapAds.h>
@interface NDMenuViewController () <UIActionSheetDelegate, UIPickerViewDataSource, UIPickerViewDelegate, ADBannerViewDelegate>

@property (strong, nonatomic) IBOutlet UIButton *buttonChooseLevel;
@property (strong, nonatomic) IBOutlet UIButton *buttonSound;
@property (strong, nonatomic) IBOutlet UILabel *labelName;
@property (strong, nonatomic) IBOutlet UIButton *buttonPlay;
@property (strong, nonatomic) IBOutlet UILabel *labelLevel;

@property (strong, nonatomic) IBOutlet UIView *viewPickerContainer;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerViewLevel;
@property (strong, nonatomic) NSTimer *timer;
@property (strong, nonatomic) IBOutletCollection(NSObject) NSArray *animable;
@property (strong, nonatomic) ADBannerView *adBannerView;

@end
BOOL isGameCenterAvailable = true;
@implementation NDMenuViewController

- (void)viewDidLoad {
 
      if ([[UIScreen mainScreen] bounds].size.height == 480.0)
      {
          self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Image"]];
      }
      else{
     self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"back"]];
      }
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self viewWillLayoutSubviews];
    
    self.adBannerView = [[ADBannerView alloc] initWithAdType:ADAdTypeBanner];
    self.adBannerView.delegate = self;
    [self.view addSubview:self.adBannerView];
    self.adBannerView.hidden = YES;
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    self.viewPickerContainer.frame = CGRectMake(0.0f, CGRectGetHeight(self.view.frame), CGRectGetWidth(self.view.frame), CGRectGetHeight(self.viewPickerContainer.frame));
    
    if ([self.timer isValid]) {
        [self.timer invalidate];
    }
    self.timer = [NSTimer scheduledTimerWithTimeInterval:5.0 target:self selector:@selector(handleTimerFire:) userInfo:nil repeats:YES];
}
- (IBAction)gamecenter:(id)sender {
    [[ABGameKitHelper sharedHelper] showLeaderboard:@"champfra"];
    [[ABGameKitHelper sharedHelper] reportScore:(long)kNDUserDefaultsLevelReached forLeaderboard:@"champfra"];
}

- (void)gameCenterViewControllerDidFinish:(GKGameCenterViewController *)gameCenterViewController
{
    [[ABGameKitHelper sharedHelper]  dismissViewControllerAnimated:YES completion:nil];
}


- (void)handleTimerFire:(NSTimer *)timer {
    
    UIView *randomUIElement = [self.animable objectAtIndex:arc4random_uniform((int)self.animable.count)];
    [UIView animateWithDuration:0.06 animations:^{
        randomUIElement.center = CGPointMake(randomUIElement.center.x + 5.0f, randomUIElement.center.y);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.06 animations:^{
            randomUIElement.center = CGPointMake(randomUIElement.center.x - 5.0f, randomUIElement.center.y);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.06 animations:^{
                randomUIElement.center = CGPointMake(randomUIElement.center.x + 5.0f, randomUIElement.center.y);
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.06 animations:^{
                    randomUIElement.center = CGPointMake(randomUIElement.center.x - 5.0f, randomUIElement.center.y);
                } completion:^(BOOL finished) {
                    [UIView animateWithDuration:0.06 animations:^{
                        randomUIElement.center = CGPointMake(randomUIElement.center.x + 5.0f, randomUIElement.center.y);
                    } completion:^(BOOL finished) {
                        [UIView animateWithDuration:0.06 animations:^{
                            randomUIElement.center = CGPointMake(randomUIElement.center.x - 5.0f, randomUIElement.center.y);
                        } completion:^(BOOL finished) {
                            
                        }];
                    }];
                }];
            }];
        }];
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    BOOL muteSound = [[NSUserDefaults standardUserDefaults] boolForKey:kNDUserDefaultsMuteSound];
    if (muteSound) {
        [self.buttonSound setImage:[UIImage imageNamed:kNDButtonImageNameSoundOff] forState:UIControlStateNormal];
    } else {
        [self.buttonSound setImage:[UIImage imageNamed:kNDButtonImageNameSoundOn] forState:UIControlStateNormal];
    }
    
    [self.pickerViewLevel reloadComponent:0];
    NSInteger currentLevel = [[NSUserDefaults standardUserDefaults] integerForKey:kNDUserDefaultsLevelCurrent];
    self.labelLevel.text = [NSString stringWithFormat:@"LEVEL %d", (int)currentLevel + 1];
    [self.pickerViewLevel selectRow:currentLevel inComponent:0 animated:NO];
}


#pragma mark - Actions methods

- (IBAction)buttonChooseLevelTouchUpInside:(UIButton *)sender {
    
    if (CGRectGetMinY(self.viewPickerContainer.frame) != CGRectGetHeight(self.view.frame)) {
        [UIView animateWithDuration:0.15 animations:^{
            self.viewPickerContainer.frame = CGRectMake(0.0f, CGRectGetHeight(self.view.frame), CGRectGetWidth(self.view.frame), CGRectGetHeight(self.viewPickerContainer.frame));
        }];
    } else {
        [UIView animateWithDuration:0.15 animations:^{
            self.viewPickerContainer.frame = CGRectMake(0.0f, CGRectGetHeight(self.view.frame) - CGRectGetHeight(self.viewPickerContainer.frame), CGRectGetWidth(self.view.frame), CGRectGetHeight(self.viewPickerContainer.frame));
        }];
    }
}



- (IBAction)buttonSoundTouchUpInside:(UIButton *)sender {
    
    BOOL muteSound = [[NSUserDefaults standardUserDefaults] boolForKey:kNDUserDefaultsMuteSound];
    
    [UIView animateWithDuration:0.1 animations:^{
        CGAffineTransform scaleUp = CGAffineTransformMakeScale(1.5f, 1.5f);
        sender.layer.affineTransform = scaleUp;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.1 animations:^{
            CGAffineTransform scaleDown = CGAffineTransformMakeScale(1.0f, 1.0f);
            sender.layer.affineTransform = scaleDown;
        } completion:^(BOOL finished) {
            
            [[NSUserDefaults standardUserDefaults] setBool:!muteSound forKey:kNDUserDefaultsMuteSound];
            if (!muteSound) {
                [sender setImage:[UIImage imageNamed:kNDButtonImageNameSoundOff] forState:UIControlStateNormal];
            } else {
                [sender setImage:[UIImage imageNamed:kNDButtonImageNameSoundOn] forState:UIControlStateNormal];
            }
        }];
    }];
}

- (IBAction)buttonPlayTouchUpInside:(UIButton *)sender {
        [GameAnalytics addDesignEventWithEventId:@"play button press"];
    if (CGRectGetMinY(self.viewPickerContainer.frame) != CGRectGetHeight(self.view.frame)) {
        [UIView animateWithDuration:0.15 animations:^{
            self.viewPickerContainer.frame = CGRectMake(0.0f, CGRectGetHeight(self.view.frame), CGRectGetWidth(self.view.frame), CGRectGetHeight(self.viewPickerContainer.frame));
        }];
    }
    NDGameViewController *gameViewController = [[NDGameViewController alloc] initWithNibName:@"NDGameViewController" bundle:nil];
    [self presentViewController:gameViewController animated:YES completion:^{ }];
}


- (IBAction)buttonDoneTouchUpInside:(UIButton *)sender {
        [GameAnalytics addDesignEventWithEventId:@"levelselect button press"];
    if (CGRectGetMinY(self.viewPickerContainer.frame) != CGRectGetHeight(self.view.frame)) {
        [UIView animateWithDuration:0.15 animations:^{
            self.viewPickerContainer.frame = CGRectMake(0.0f, CGRectGetHeight(self.view.frame), CGRectGetWidth(self.view.frame), CGRectGetHeight(self.viewPickerContainer.frame));
        }];
    }
}


#pragma mark - UIActionSheetDelegate methods


#pragma mark - UIPickerViewDataSource methods

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    NSInteger maxLevels = kNDMaxNodesLocked - kNDMinNodesLocked;
    return maxLevels;
}


#pragma mark - UIPickerViewDelegate methods

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    
    NSString *title = [NSString stringWithFormat:@"LEVEL %d", (int)row + 1];
    return title;
}

- (NSAttributedString *)pickerView:(UIPickerView *)pickerView attributedTitleForRow:(NSInteger)row forComponent:(NSInteger)component {
      //  NSInteger reachedLevel = 20;
   NSInteger reachedLevel = [[NSUserDefaults standardUserDefaults] integerForKey:kNDUserDefaultsLevelReached];
    NSString *titleText = [NSString stringWithFormat:@"LEVEL %d", (int)row + 1];
    UIColor *textColor;
    if (row <= reachedLevel) {
        textColor = [UIColor blackColor];
    } else {
        textColor = [UIColor lightGrayColor];
    }
    NSMutableAttributedString *title = [[NSMutableAttributedString alloc] initWithString:titleText attributes:@{NSForegroundColorAttributeName : textColor}];
    return title;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    NSInteger reachedLevel = 20;
   // NSInteger reachedLevel = [[NSUserDefaults standardUserDefaults] integerForKey:kNDUserDefaultsLevelReached];
    if (row <= reachedLevel) {
        [[NSUserDefaults standardUserDefaults] setInteger:row forKey:kNDUserDefaultsLevelCurrent];
        self.labelLevel.text = [NSString stringWithFormat:@"LEVEL %d", (int)row + 1];
    } else {
        [pickerView selectRow:reachedLevel inComponent:0 animated:YES];
        [[NSUserDefaults standardUserDefaults] setInteger:reachedLevel forKey:kNDUserDefaultsLevelCurrent];
        self.labelLevel.text = [NSString stringWithFormat:@"LEVEL %d", (int)reachedLevel + 1];
    }
}


#pragma mark - ADBannerViewDelegate methods
/*
- (void)bannerViewDidLoadAd:(ADBannerView *)banner {
    
    self.adBannerView.hidden = NO;
    self.adBannerView.frame = CGRectMake(0.0f, CGRectGetHeight(self.view.frame), CGRectGetWidth(self.view.frame), CGRectGetHeight(self.adBannerView.frame));
    [UIView animateWithDuration:0.15 animations:^{
        self.adBannerView.frame = CGRectMake(0.0f, CGRectGetHeight(self.view.frame) - CGRectGetHeight(self.adBannerView.frame), CGRectGetWidth(self.view.frame), CGRectGetHeight(self.adBannerView.frame));
    }];
}
 
- (void)bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error {
    
    [UIView animateWithDuration:0.15 animations:^{
        self.adBannerView.frame = CGRectMake(0.0f, CGRectGetHeight(self.view.frame), CGRectGetWidth(self.view.frame), CGRectGetHeight(self.adBannerView.frame));
    }];
}
 */

@end
