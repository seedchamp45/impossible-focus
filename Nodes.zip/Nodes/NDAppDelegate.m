//
//  AppDelegate.m
//  Nodes
//
//  Created by Planet 1107 on 19/01/15.
//  Copyright (c) 2015 Planet 1107. All rights reserved.
//
@import AdSupport;
@import CoreGraphics;
@import CoreLocation;
@import CoreTelephony;
@import EventKit;
@import EventKitUI;
@import MediaPlayer;
@import MessageUI;
@import MobileCoreServices;
@import QuartzCore;
@import Security;
@import StoreKit;
@import SystemConfiguration;
@import iAd;
//#import <HeyzapAds/HeyzapAds.h>
#import "NDAppDelegate.h"
#import "NDMenuViewController.h"

#import <CommonCrypto/CommonDigest.h>
#import <AdSupport/AdSupport.h>
#import "GameAnalytics.h"

#import <Chartboost/Chartboost.h>


@interface NDAppDelegate ()

@end

@implementation NDAppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [GameAnalytics configureBuild:@"alpha 0.1.0"];
    [GameAnalytics initializeWithGameKey:@"892d6d983bd0174a627a4cea9d0660d0" gameSecret:@"c2731dd2d393e8227f887d73bca363d1ef680635"];
    [GameAnalytics addErrorEventWithSeverity:GAErrorSeverityDebug message:@"Something went bad in some of the smelly code!"];
    //[HeyzapAds startWithPublisherID: @"f9ffec7444f543f2a428e4b6f22c75be"];
    //[HeyzapAds presentMediationDebugViewController];
    [Chartboost startWithAppId:@"5616285df6cd4553b1ae7d2e"
                  appSignature:@"20f97986dc7000d654ac305bb44d40e770e2b324"
                      delegate:self];
    // Override point for customization after application launch.


    // Initialize the Chartboost library
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    NDMenuViewController *menuViewController = [[NDMenuViewController alloc] initWithNibName:@"NDMenuViewController" bundle:nil];
    self.window.rootViewController = menuViewController;
    
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
