//
//  NDSprite.h
//  Nodes
//
//  Created by Planet 1107 on 20/01/15.
//  Copyright (c) 2015 Planet 1107. All rights reserved.
//

#import "PNTSprite.h"

#define kNDNodeCategoryMask 0x000000F0

typedef enum : NSUInteger {
    NDNodeCenter = 0,
    NDNodeLocked = 1,
    NDNodeFree = 2
} NDNodeType;

typedef enum : NSUInteger {
    NDNodeBlack = 0,
    NDNodePink = 1,
    NDNodeYellow = 2,
    NDNodeBlue = 3
} NDNodeColor;

@interface NDNode : PNTSprite

@property (nonatomic) NDNodeType nodeType;
@property (nonatomic, setter=setNodeColor:) NDNodeColor nodeColor;
@property (strong, nonatomic) SKLabelNode *labelNumber;
@property (strong, nonatomic) SKSpriteNode *nodeLink;

- (void)loadPhysics;
- (void)startRotating;
- (void)startRotating2;
- (void)startRotating3;
- (void)startRotating4;
- (void)startRotating5;
- (void)stopRotating;
- (BOOL)isRotating;
- (SKPhysicsJointFixed *)createLinkToCenterNode:(NDNode *)centerNode;

@end
